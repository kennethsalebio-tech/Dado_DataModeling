import { Pet } from "../models/PetModel.js";

export const petController = {
    selectAll: async (req, res) => {
        try {
            const data = await Pet.findAll();
            res.json({ status: "success", data });
        } catch (error) {
            res.status(500).json({ status: "error", message: error.message });
        }
    },
    selectById: async (req, res) => {
        try {
            const data = await Pet.findByPk(req.params.id);
            res.json({ status: "success", data });
        } catch (error) {
            res.status(500).json({ status: "error", message: error.message });
        }
    },
    insert: async (req, res) => {
        try {
            const data = await Pet.create(req.body);
            res.status(201).json({ status: "success", data });
        } catch (error) {
            res.status(400).json({ status: "error", message: error.message });
        }
    }
};