import { Bill } from "../models/BillModel.js";

export const billController = {
    selectAll: async (req, res) => {
        try {
            const data = await Bill.findAll();
            res.json({ status: "success", data });
        } catch (error) {
            res.status(500).json({ status: "error", message: error.message });
        }
    },
    selectById: async (req, res) => {
        try {
            const data = await Bill.findByPk(req.params.id);
            res.json({ status: "success", data });
        } catch (error) {
            res.status(500).json({ status: "error", message: error.message });
        }
    },
    insert: async (req, res) => {
        try {
            const data = await Bill.create(req.body);
            res.status(201).json({ status: "success", data });
        } catch (error) {
            res.status(400).json({ status: "error", message: error.message });
        }
    }
};