import { Appointment } from "../models/AppointmentModel.js";

export const appointmentController = {
    selectAll: async (req, res) => {
        try {
            const data = await Appointment.findAll();
            res.json({ status: "success", data });
        } catch (error) {
            res.status(500).json({ status: "error", message: error.message });
        }
    },
    selectById: async (req, res) => {
        try {
            const data = await Appointment.findByPk(req.params.id);
            res.json({ status: "success", data });
        } catch (error) {
            res.status(500).json({ status: "error", message: error.message });
        }
    },
    insert: async (req, res) => {
        try {
            const data = await Appointment.create(req.body);
            res.status(201).json({ status: "success", data });
        } catch (error) {
            res.status(400).json({ status: "error", message: error.message });
        }
    }
};