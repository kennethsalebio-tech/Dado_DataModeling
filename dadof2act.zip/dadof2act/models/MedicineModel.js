import { DataTypes } from "sequelize";
import { sequelize } from "./db.js";

export const Medicine = sequelize.define("Medicine", {
    medicineName: { type: DataTypes.STRING, allowNull: false },
    category: { type: DataTypes.STRING, allowNull: false },
    unitPrice: { type: DataTypes.DECIMAL(10,2), allowNull: false },
    stockQuantity: { type: DataTypes.INTEGER, allowNull: false },
    supplier: { type: DataTypes.STRING, allowNull: false }
});