import { DataTypes } from "sequelize";
import { sequelize } from "./db.js";

export const Appointment = sequelize.define("Appointment", {
    petId: { type: DataTypes.INTEGER, allowNull: false },
    vetName: { type: DataTypes.STRING, allowNull: false },
    appointmentDate: { type: DataTypes.DATE, allowNull: false },
    status: { type: DataTypes.STRING, defaultValue: 'scheduled' },
    reason: { type: DataTypes.TEXT, allowNull: false }
});