import { DataTypes } from "sequelize";
import { sequelize } from "./db.js";

export const Bill = sequelize.define("Bill", {
    petId: { type: DataTypes.INTEGER, allowNull: false },
    totalAmount: { type: DataTypes.DECIMAL(10,2), allowNull: false },
    paymentStatus: { type: DataTypes.STRING, defaultValue: 'unpaid' },
    paymentMethod: { type: DataTypes.STRING, allowNull: true },
    discountApplied: { type: DataTypes.DECIMAL(10,2), defaultValue: 0.00 }
});