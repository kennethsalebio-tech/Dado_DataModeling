import { DataTypes } from "sequelize";
import { sequelize } from "./db.js";

export const Pet = sequelize.define("Pet", {
    ownerId: { type: DataTypes.INTEGER, allowNull: false },
    petName: { type: DataTypes.STRING, allowNull: false },
    species: { type: DataTypes.STRING, allowNull: false },
    breed: { type: DataTypes.STRING, allowNull: false },
    age: { type: DataTypes.INTEGER, allowNull: false }
});