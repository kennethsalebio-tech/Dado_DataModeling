import { Sequelize } from "sequelize";
import { sequelize } from "./models/db.js";
import { Owner } from "./models/OwnerModel.js";
import { Pet } from "./models/PetModel.js";
import { Appointment } from "./models/AppointmentModel.js";
import { Medicine } from "./models/MedicineModel.js";
import { Bill } from "./models/BillModel.js";
import inquirer from "inquirer";

const rootSequelize = new Sequelize("mysql://root:@localhost:3306/");

const { createDb } = await inquirer.prompt([
    {
        type: "confirm",
        name: "createDb",
        message: "Database 'dadof2act' may not exist. Create it?",
        default: true,
    },
]);

if (createDb) {
    await rootSequelize.query("CREATE DATABASE IF NOT EXISTS dadof2act;");
    console.log("✅ Database created (if it did not exist)");
}

try {
    await sequelize.authenticate();
    console.log("✅ Connected to MySQL database!");
    await sequelize.sync({ force: true });
    console.log("✅ Tables created for all models!");
} catch (err) {
    console.error("❌ Migration failed:", err);
} finally {
    process.exit();
}