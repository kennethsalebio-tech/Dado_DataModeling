
  /*
    MIT License
    
    Copyright (c) 2025 Christian I. Cabrera || XianFire Framework
    Mindoro State University - Philippines

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
    */
    
import express from "express";
import { homePage } from "../controllers/homeController.js";
const router = express.Router();
router.get("/", homePage);

import { loginPage, registerPage, forgotPasswordPage, dashboardPage, loginUser, registerUser, logoutUser } from "../controllers/authController.js";

router.get("/login", loginPage);
router.post("/login", loginUser);
router.get("/register", registerPage);
router.post("/register", registerUser);
router.get("/forgot-password", forgotPasswordPage);
router.get("/dashboard", dashboardPage);
router.get("/logout", logoutUser);

import { ownerController } from "../controllers/OwnerController.js";
import { petController } from "../controllers/PetController.js";
import { appointmentController } from "../controllers/AppointmentController.js";
import { medicineController } from "../controllers/MedicineController.js";
import { billController } from "../controllers/BillController.js";


router.get("/owners", ownerController.selectAll);
router.get("/owners/:id", ownerController.selectById);
router.post("/owners", ownerController.insert);

router.get("/pets", petController.selectAll);
router.get("/pets/:id", petController.selectById);
router.post("/pets", petController.insert);

router.get("/appointments", appointmentController.selectAll);
router.get("/appointments/:id", appointmentController.selectById);
router.post("/appointments", appointmentController.insert);

router.get("/medicines", medicineController.selectAll);
router.get("/medicines/:id", medicineController.selectById);
router.post("/medicines", medicineController.insert);

router.get("/bills", billController.selectAll);
router.get("/bills/:id", billController.selectById);
router.post("/bills", billController.insert);

export default router;